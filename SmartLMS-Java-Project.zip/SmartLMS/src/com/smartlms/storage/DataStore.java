package com.smartlms.storage;

import com.smartlms.model.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class DataStore implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String DATA_FILE = "data/lms_data.dat";

    private final Map<String, User> users = new LinkedHashMap<>();
    private final Map<String, Course> courses = new LinkedHashMap<>();
    private final List<Enrollment> enrollments = new ArrayList<>();
    private final List<Notification> notifications = new ArrayList<>();

    public Map<String, User> getUsers() { return users; }
    public Map<String, Course> getCourses() { return courses; }
    public List<Enrollment> getEnrollments() { return enrollments; }
    public List<Notification> getNotifications() { return notifications; }

    public static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm unavailable", e);
        }
    }

    public void save() {
        File file = new File(DATA_FILE);
        if (file.getParentFile() != null) {
            file.getParentFile().mkdirs();
        }
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(this);
        } catch (IOException e) {
            System.err.println("Warning: Could not save data: " + e.getMessage());
        }
    }

    public static DataStore loadOrCreate() {
        File file = new File(DATA_FILE);
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                return (DataStore) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Warning: Could not load saved data, creating fresh store.");
            }
        }
        DataStore store = new DataStore();
        store.seedInitialData();
        store.save();
        return store;
    }

    private void seedInitialData() {
        // Seed Users
        User admin = new User("U100", "System Admin", "admin@smartlms.edu", sha256("admin123"), Role.ADMIN);
        User inst1 = new User("U201", "Dr. Rahim Uddin", "rahim@smartlms.edu", sha256("inst123"), Role.INSTRUCTOR);
        User inst2 = new User("U202", "Prof. Ananya Sen", "ananya@smartlms.edu", sha256("inst123"), Role.INSTRUCTOR);
        User stud1 = new User("U301", "Arafat Rahman", "student@smartlms.edu", sha256("stud123"), Role.STUDENT);
        User stud2 = new User("U302", "Meera Roy", "meera@smartlms.edu", sha256("stud123"), Role.STUDENT);

        users.put(admin.getId(), admin);
        users.put(inst1.getId(), inst1);
        users.put(inst2.getId(), inst2);
        users.put(stud1.getId(), stud1);
        users.put(stud2.getId(), stud2);

        // Course 1: Core Java
        Course c1 = new Course("C101", "Core Java & OOP Mastery", "Programming",
                Course.Difficulty.BEGINNER, inst1.getId(), 50);
        c1.addTag("java");
        c1.addTag("oop");
        c1.addTag("backend");
        c1.addLesson(new Lesson("L101-1", "Java Basics & JVM Architecture", 30, "Variables, types, and how the JVM executes bytecode."));
        c1.addLesson(new Lesson("L101-2", "Classes, Objects & Inheritance", 45, "Encapsulation, polymorphism, and inheritance hierarchies."));
        c1.addLesson(new Lesson("L101-3", "Collections & Streams API", 50, "List, Set, Map, and functional stream pipelines."));

        Quiz q1 = new Quiz("Q101-1", "Java OOP Fundamentals Quiz");
        q1.addQuestion(new Question("Which keyword is used to inherit a class in Java?",
                Arrays.asList("implements", "extends", "inherits", "super"), 1));
        q1.addQuestion(new Question("Which collection guarantees unique elements?",
                Arrays.asList("ArrayList", "LinkedList", "HashSet", "Vector"), 2));
        c1.addQuiz(q1);

        // Course 2: DSA in Java
        Course c2 = new Course("C102", "Data Structures & Algorithms in Java", "Computer Science",
                Course.Difficulty.INTERMEDIATE, inst1.getId(), 40);
        c2.addTag("java");
        c2.addTag("algorithms");
        c2.addTag("dsa");
        c2.addLesson(new Lesson("L102-1", "Time & Space Complexity (Big-O)", 35, "Asymptotic analysis for efficient algorithms."));
        c2.addLesson(new Lesson("L102-2", "Trees, Heaps & Graphs", 60, "BFS, DFS, and priority queue implementations."));

        Quiz q2 = new Quiz("Q102-1", "DSA Complexity Quiz");
        q2.addQuestion(new Question("What is the average time complexity of Binary Search?",
                Arrays.asList("O(n)", "O(log n)", "O(n log n)", "O(1)"), 1));
        c2.addQuiz(q2);

        // Course 3: Spring Boot Microservices
        Course c3 = new Course("C103", "Spring Boot & REST APIs", "Backend Development",
                Course.Difficulty.ADVANCED, inst1.getId(), 35);
        c3.addTag("java");
        c3.addTag("spring");
        c3.addTag("backend");
        c3.addTag("api");
        c3.addLesson(new Lesson("L103-1", "Dependency Injection & IoC", 40, "Spring container, beans, and configuration."));
        c3.addLesson(new Lesson("L103-2", "Building RESTful Controllers", 55, "HTTP methods, validation, and exception handling."));

        // Course 4: Machine Learning Foundations
        Course c4 = new Course("C104", "Machine Learning Foundations", "Data Science",
                Course.Difficulty.BEGINNER, inst2.getId(), 60);
        c4.addTag("ml");
        c4.addTag("ai");
        c4.addTag("algorithms");
        c4.addLesson(new Lesson("L104-1", "Supervised vs Unsupervised Learning", 30, "Regression, classification, and clustering overview."));
        c4.addLesson(new Lesson("L104-2", "Model Evaluation Metrics", 40, "Accuracy, precision, recall, and F1-score."));

        courses.put(c1.getId(), c1);
        courses.put(c2.getId(), c2);
        courses.put(c3.getId(), c3);
        courses.put(c4.getId(), c4);

        // Seed Enrollments
        Enrollment e1 = new Enrollment(stud1.getId(), c1.getId());
        e1.markLessonCompleted("L101-1");
        e1.recordQuizScore("Q101-1", 100.0);
        enrollments.add(e1);

        Enrollment e2 = new Enrollment(stud2.getId(), c1.getId());
        e2.recordQuizScore("Q101-1", 40.0);
        enrollments.add(e2);

        notifications.add(new Notification("N1", stud1.getId(), "Welcome to SmartLMS! Your learning path is ready."));
        notifications.add(new Notification("N2", stud2.getId(), "Welcome to SmartLMS! Complete your pending lessons in C101."));
    }
}
