package com.smartlms;

import com.smartlms.storage.DataStore;
import com.smartlms.ui.ConsoleUI;

public class Main {
    public static void main(String[] args) {
        DataStore store = DataStore.loadOrCreate();
        ConsoleUI ui = new ConsoleUI(store);
        ui.start();
    }
}
