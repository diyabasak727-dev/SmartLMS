package com.smartlms.ui;

import com.smartlms.model.*;
import com.smartlms.service.*;
import com.smartlms.storage.DataStore;
import java.util.*;

public class ConsoleUI {
    private final Scanner scanner = new Scanner(System.in);
    private final AuthService authService;
    private final CourseService courseService;
    private final EnrollmentService enrollmentService;
    private final SmartRecommendationEngine smartEngine;
    private final AnalyticsService analyticsService;
    private User currentUser;

    public ConsoleUI(DataStore store) {
        this.authService = new AuthService(store);
        this.courseService = new CourseService(store);
        this.enrollmentService = new EnrollmentService(store);
        this.smartEngine = new SmartRecommendationEngine(store);
        this.analyticsService = new AnalyticsService(store);
    }

    public void start() {
        System.out.println("====================================================");
        System.out.println("     SMART LEARNING MANAGEMENT SYSTEM (SmartLMS)    ");
        System.out.println("====================================================");
        while (true) {
            if (currentUser == null) {
                showWelcomeMenu();
            } else {
                switch (currentUser.getRole()) {
                    case STUDENT -> showStudentMenu();
                    case INSTRUCTOR -> showInstructorMenu();
                    case ADMIN -> showAdminMenu();
                }
            }
        }
    }

    private void showWelcomeMenu() {
        System.out.println("\n1. Login");
        System.out.println("2. Register New Account");
        System.out.println("3. View Demo Accounts");
        System.out.println("0. Exit");
        int choice = readInt("Choose an option: ");
        switch (choice) {
            case 1 -> handleLogin();
            case 2 -> handleRegister();
            case 3 -> showDemoAccounts();
            case 0 -> {
                System.out.println("Goodbye! Happy learning.");
                System.exit(0);
            }
            default -> System.out.println("Invalid option.");
        }
    }

    private void showDemoAccounts() {
        System.out.println("\n--- Demo Accounts ---");
        System.out.println("Student   : student@smartlms.edu  / stud123");
        System.out.println("Instructor: rahim@smartlms.edu    / inst123");
        System.out.println("Admin     : admin@smartlms.edu    / admin123");
    }

    private void handleLogin() {
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String pass = scanner.nextLine();
        Optional<User> user = authService.login(email, pass);
        if (user.isPresent()) {
            currentUser = user.get();
            System.out.println("\nWelcome back, " + currentUser.getName() + " [" + currentUser.getRole() + "]!");
        } else {
            System.out.println("Invalid email or password.");
        }
    }

    private void handleRegister() {
        System.out.print("Full Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Password: ");
        String pass = scanner.nextLine();
        System.out.println("Role: 1. Student  2. Instructor");
        int roleChoice = readInt("Select role: ");
        Role role = (roleChoice == 2) ? Role.INSTRUCTOR : Role.STUDENT;
        try {
            User created = authService.register(name, email, pass, role);
            System.out.println("Registered successfully! ID: " + created.getId());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void showStudentMenu() {
        System.out.println("\n--- STUDENT DASHBOARD (" + currentUser.getName() + ") ---");
        System.out.println("Summary: " + analyticsService.getStudentSummary(currentUser.getId()));
        System.out.println("1. Browse All Courses");
        System.out.println("2. Search Courses by Keyword/Tag");
        System.out.println("3. Enroll in a Course");
        System.out.println("4. My Enrolled Courses & Progress");
        System.out.println("5. Complete a Lesson");
        System.out.println("6. Take a Course Quiz");
        System.out.println("7. [SMART] Get Personalized Course Recommendations");
        System.out.println("8. [SMART] Generate Adaptive Study Plan");
        System.out.println("9. View Notifications");
        System.out.println("0. Logout");

        int choice = readInt("Choose an option: ");
        switch (choice) {
            case 1 -> listAllCourses();
            case 2 -> searchCourses();
            case 3 -> enrollInCourse();
            case 4 -> viewMyEnrollments();
            case 5 -> completeLesson();
            case 6 -> takeQuiz();
            case 7 -> showSmartRecommendations();
            case 8 -> showAdaptiveStudyPlan();
            case 9 -> viewNotifications();
            case 0 -> currentUser = null;
            default -> System.out.println("Invalid option.");
        }
    }

    private void showInstructorMenu() {
        System.out.println("\n--- INSTRUCTOR DASHBOARD (" + currentUser.getName() + ") ---");
        System.out.println("1. View My Courses");
        System.out.println("2. Create New Course");
        System.out.println("3. Add Lesson to Course");
        System.out.println("4. Add Quiz to Course");
        System.out.println("5. View Course Analytics");
        System.out.println("6. [SMART] Detect At-Risk Students");
        System.out.println("0. Logout");

        int choice = readInt("Choose an option: ");
        switch (choice) {
            case 1 -> listInstructorCourses();
            case 2 -> createCourse();
            case 3 -> addLesson();
            case 4 -> addQuiz();
            case 5 -> viewCourseAnalytics();
            case 6 -> detectAtRiskStudents();
            case 0 -> currentUser = null;
            default -> System.out.println("Invalid option.");
        }
    }

    private void showAdminMenu() {
        System.out.println("\n--- ADMIN DASHBOARD (" + currentUser.getName() + ") ---");
        System.out.println("1. List All Users");
        System.out.println("2. List All Courses");
        System.out.println("3. View Course Analytics");
        System.out.println("4. Top Students Leaderboard");
        System.out.println("0. Logout");

        int choice = readInt("Choose an option: ");
        switch (choice) {
            case 1 -> authService.getAllUsers().forEach(System.out::println);
            case 2 -> listAllCourses();
            case 3 -> viewCourseAnalytics();
            case 4 -> {
                System.out.println("\n--- Top Students Leaderboard ---");
                List<String> top = analyticsService.getTopStudentsLeaderboard(5);
                if (top.isEmpty()) System.out.println("No quiz data yet.");
                else top.forEach(System.out::println);
            }
            case 0 -> currentUser = null;
            default -> System.out.println("Invalid option.");
        }
    }

    private void listAllCourses() {
        System.out.println("\n--- Course Catalog ---");
        for (Course c : courseService.getAllCourses()) {
            System.out.println(c + " | Tags: " + c.getTags());
        }
    }

    private void searchCourses() {
        System.out.print("Enter keyword or tag: ");
        String kw = scanner.nextLine();
        List<Course> results = courseService.searchCourses(kw);
        if (results.isEmpty()) System.out.println("No matching courses found.");
        else results.forEach(System.out::println);
    }

    private void enrollInCourse() {
        System.out.print("Enter Course ID (e.g., C102): ");
        String cid = scanner.nextLine();
        try {
            enrollmentService.enrollStudent(currentUser.getId(), cid);
            System.out.println("Successfully enrolled in " + cid.toUpperCase() + "!");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void viewMyEnrollments() {
        List<Enrollment> list = enrollmentService.getStudentEnrollments(currentUser.getId());
        if (list.isEmpty()) {
            System.out.println("You are not enrolled in any courses.");
            return;
        }
        for (Enrollment e : list) {
            Course c = courseService.getCourseById(e.getCourseId()).orElse(null);
            if (c == null) continue;
            double prog = e.getProgressPercentage(c.getLessons().size());
            System.out.printf("%s (%s) -> Progress: %.1f%% | Avg Quiz: %.1f%%%n",
                    c.getTitle(), c.getId(), prog, e.getAverageQuizScore());
            for (Lesson l : c.getLessons()) {
                String done = e.getCompletedLessonIds().contains(l.getId()) ? "[DONE]" : "[    ]";
                System.out.println("   " + done + " " + l);
            }
        }
    }

    private void completeLesson() {
        System.out.print("Enter Course ID: ");
        String cid = scanner.nextLine();
        System.out.print("Enter Lesson ID (e.g., L101-2): ");
        String lid = scanner.nextLine();
        try {
            enrollmentService.markLessonComplete(currentUser.getId(), cid, lid);
            System.out.println("Lesson marked as completed!");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void takeQuiz() {
        System.out.print("Enter Course ID: ");
        String cid = scanner.nextLine().trim().toUpperCase();
        Optional<Course> opt = courseService.getCourseById(cid);
        if (opt.isEmpty()) {
            System.out.println("Course not found.");
            return;
        }
        Course c = opt.get();
        if (c.getQuizzes().isEmpty()) {
            System.out.println("No quizzes available in this course.");
            return;
        }
        for (Quiz q : c.getQuizzes()) {
            System.out.println(q.getId() + ": " + q.getTitle());
        }
        System.out.print("Enter Quiz ID: ");
        String qid = scanner.nextLine().trim().toUpperCase();
        Quiz quiz = c.getQuizzes().stream()
                .filter(q -> q.getId().equalsIgnoreCase(qid))
                .findFirst().orElse(null);
        if (quiz == null) {
            System.out.println("Quiz not found.");
            return;
        }
        List<Integer> answers = new ArrayList<>();
        int qNum = 1;
        for (Question q : quiz.getQuestions()) {
            System.out.println("\nQ" + qNum++ + ": " + q.getPrompt());
            List<String> opts = q.getOptions();
            for (int i = 0; i < opts.size(); i++) {
                System.out.println("  " + (i + 1) + ". " + opts.get(i));
            }
            int ans = readInt("Your answer (1-" + opts.size() + "): ") - 1;
            answers.add(ans);
        }
        try {
            double score = enrollmentService.submitQuiz(currentUser.getId(), cid, qid, answers);
            System.out.printf("Quiz submitted! Your score: %.1f%%%n", score);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void showSmartRecommendations() {
        System.out.println("\n--- Smart Course Recommendations ---");
        List<SmartRecommendationEngine.CourseRecommendation> recs =
                smartEngine.recommendCoursesForStudent(currentUser.getId(), 3);
        if (recs.isEmpty()) {
            System.out.println("You are already enrolled in all available courses!");
            return;
        }
        for (SmartRecommendationEngine.CourseRecommendation r : recs) {
            System.out.printf("* %s (Match Score: %.0f) -> Reason: %s%n",
                    r.getCourse().toString(), r.getMatchScore(), r.getReason());
        }
    }

    private void showAdaptiveStudyPlan() {
        int mins = readInt("How many minutes per day can you study? ");
        List<SmartRecommendationEngine.StudyPlanItem> plan =
                smartEngine.generateStudyPlan(currentUser.getId(), mins);
        if (plan.isEmpty()) {
            System.out.println("All lessons in your enrolled courses are complete!");
            return;
        }
        System.out.println("\n--- Your Adaptive Study Plan ---");
        for (SmartRecommendationEngine.StudyPlanItem item : plan) {
            System.out.printf("Day %d | %s -> %s (%d min)%n",
                    item.getDay(), item.getCourseTitle(),
                    item.getLesson().getTitle(), item.getLesson().getDurationMinutes());
        }
    }

    private void viewNotifications() {
        List<Notification> list = enrollmentService.getUserNotifications(currentUser.getId());
        if (list.isEmpty()) {
            System.out.println("No notifications.");
            return;
        }
        System.out.println("\n--- Notifications ---");
        list.forEach(System.out::println);
        enrollmentService.markAllNotificationsRead(currentUser.getId());
    }

    private void listInstructorCourses() {
        List<Course> list = courseService.getCoursesByInstructor(currentUser.getId());
        if (list.isEmpty()) System.out.println("You haven't created any courses yet.");
        else list.forEach(System.out::println);
    }

    private void createCourse() {
        System.out.print("Course Title: ");
        String title = scanner.nextLine();
        System.out.print("Category: ");
        String category = scanner.nextLine();
        System.out.println("Difficulty: 1. BEGINNER  2. INTERMEDIATE  3. ADVANCED");
        int d = readInt("Select difficulty: ");
        Course.Difficulty diff = switch (d) {
            case 2 -> Course.Difficulty.INTERMEDIATE;
            case 3 -> Course.Difficulty.ADVANCED;
            default -> Course.Difficulty.BEGINNER;
        };
        int max = readInt("Max Students: ");
        System.out.print("Tags (comma-separated, e.g., java,oop): ");
        String tagLine = scanner.nextLine();
        List<String> tags = Arrays.asList(tagLine.split(","));
        Course c = courseService.createCourse(title, category, diff, currentUser.getId(), max, tags);
        System.out.println("Created course: " + c);
    }

    private void addLesson() {
        System.out.print("Course ID: ");
        String cid = scanner.nextLine();
        System.out.print("Lesson Title: ");
        String title = scanner.nextLine();
        int mins = readInt("Duration (minutes): ");
        System.out.print("Summary: ");
        String summary = scanner.nextLine();
        try {
            Lesson l = courseService.addLessonToCourse(cid, title, mins, summary);
            System.out.println("Added lesson: " + l);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void addQuiz() {
        System.out.print("Course ID: ");
        String cid = scanner.nextLine().trim().toUpperCase();
        Optional<Course> opt = courseService.getCourseById(cid);
        if (opt.isEmpty()) {
            System.out.println("Course not found.");
            return;
        }
        System.out.print("Quiz Title: ");
        String title = scanner.nextLine();
        String qid = "Q" + cid.replaceAll("\\D+", "") + "-" + (opt.get().getQuizzes().size() + 1);
        Quiz quiz = new Quiz(qid, title);
        int count = readInt("How many questions? ");
        for (int i = 1; i <= count; i++) {
            System.out.print("Question " + i + " prompt: ");
            String prompt = scanner.nextLine();
            List<String> options = new ArrayList<>();
            for (int o = 1; o <= 4; o++) {
                System.out.print("  Option " + o + ": ");
                options.add(scanner.nextLine());
            }
            int correct = readInt("Correct option number (1-4): ") - 1;
            quiz.addQuestion(new Question(prompt, options, Math.max(0, Math.min(3, correct))));
        }
        courseService.addQuizToCourse(cid, quiz);
        System.out.println("Quiz " + qid + " added!");
    }

    private void viewCourseAnalytics() {
        System.out.print("Enter Course ID: ");
        String cid = scanner.nextLine();
        System.out.println(analyticsService.getCourseAnalytics(cid));
    }

    private void detectAtRiskStudents() {
        System.out.print("Enter Course ID: ");
        String cid = scanner.nextLine();
        List<String> alerts = smartEngine.detectAtRiskStudents(cid);
        if (alerts.isEmpty()) {
            System.out.println("No at-risk students detected in " + cid.toUpperCase() + ".");
        } else {
            System.out.println("\n--- At-Risk Students Alert ---");
            alerts.forEach(System.out::println);
        }
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
