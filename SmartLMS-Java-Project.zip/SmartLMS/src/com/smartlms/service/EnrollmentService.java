package com.smartlms.service;

import com.smartlms.model.*;
import com.smartlms.storage.DataStore;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EnrollmentService {
    private final DataStore store;

    public EnrollmentService(DataStore store) {
        this.store = store;
    }

    public Enrollment enrollStudent(String studentId, String courseId) {
        Course course = store.getCourses().get(courseId.trim().toUpperCase());
        if (course == null) {
            throw new IllegalArgumentException("Course not found: " + courseId);
        }
        if (findEnrollment(studentId, course.getId()).isPresent()) {
            throw new IllegalStateException("Already enrolled in " + course.getTitle());
        }
        long currentCount = getCourseEnrollments(course.getId()).size();
        if (currentCount >= course.getMaxStudents()) {
            throw new IllegalStateException("Course is full (max " + course.getMaxStudents() + " students).");
        }
        Enrollment enrollment = new Enrollment(studentId, course.getId());
        store.getEnrollments().add(enrollment);
        addNotification(studentId, "Enrolled in course: " + course.getTitle() + " (" + course.getId() + ")");
        store.save();
        return enrollment;
    }

    public Optional<Enrollment> findEnrollment(String studentId, String courseId) {
        return store.getEnrollments().stream()
                .filter(e -> e.getStudentId().equals(studentId) && e.getCourseId().equalsIgnoreCase(courseId))
                .findFirst();
    }

    public List<Enrollment> getStudentEnrollments(String studentId) {
        return store.getEnrollments().stream()
                .filter(e -> e.getStudentId().equals(studentId))
                .collect(Collectors.toList());
    }

    public List<Enrollment> getCourseEnrollments(String courseId) {
        return store.getEnrollments().stream()
                .filter(e -> e.getCourseId().equalsIgnoreCase(courseId))
                .collect(Collectors.toList());
    }

    public void markLessonComplete(String studentId, String courseId, String lessonId) {
        Enrollment enrollment = findEnrollment(studentId, courseId)
                .orElseThrow(() -> new IllegalStateException("You are not enrolled in " + courseId));
        Course course = store.getCourses().get(courseId.toUpperCase());
        boolean lessonExists = course != null && course.getLessons().stream()
                .anyMatch(l -> l.getId().equalsIgnoreCase(lessonId));
        if (!lessonExists) {
            throw new IllegalArgumentException("Lesson not found in course: " + lessonId);
        }
        enrollment.markLessonCompleted(lessonId.toUpperCase());
        if (enrollment.getProgressPercentage(course.getLessons().size()) >= 100.0) {
            addNotification(studentId, "Congratulations! You completed all lessons in " + course.getTitle());
        }
        store.save();
    }

    public double submitQuiz(String studentId, String courseId, String quizId, List<Integer> selectedAnswers) {
        Enrollment enrollment = findEnrollment(studentId, courseId)
                .orElseThrow(() -> new IllegalStateException("You are not enrolled in " + courseId));
        Course course = store.getCourses().get(courseId.toUpperCase());
        if (course == null) {
            throw new IllegalArgumentException("Course not found: " + courseId);
        }
        Quiz quiz = course.getQuizzes().stream()
                .filter(q -> q.getId().equalsIgnoreCase(quizId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Quiz not found: " + quizId));

        List<Question> questions = quiz.getQuestions();
        if (questions.isEmpty()) return 100.0;

        int correctCount = 0;
        for (int i = 0; i < questions.size() && i < selectedAnswers.size(); i++) {
            if (questions.get(i).isCorrect(selectedAnswers.get(i))) {
                correctCount++;
            }
        }
        double score = (correctCount * 100.0) / questions.size();
        enrollment.recordQuizScore(quiz.getId(), score);

        if (score >= 80.0) {
            addNotification(studentId, String.format("Great job! Scored %.1f%% on %s.", score, quiz.getTitle()));
        } else if (score < 50.0) {
            addNotification(studentId, String.format("Smart Alert: Scored %.1f%% on %s. Review the lessons and retry!", score, quiz.getTitle()));
        }
        store.save();
        return score;
    }

    public List<Notification> getUserNotifications(String userId) {
        return store.getNotifications().stream()
                .filter(n -> n.getUserId().equals(userId))
                .collect(Collectors.toList());
    }

    public void markAllNotificationsRead(String userId) {
        store.getNotifications().stream()
                .filter(n -> n.getUserId().equals(userId))
                .forEach(Notification::markAsRead);
        store.save();
    }

    private void addNotification(String userId, String message) {
        String id = "N" + (store.getNotifications().size() + 1);
        store.getNotifications().add(new Notification(id, userId, message));
    }
}
