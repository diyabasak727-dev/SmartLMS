package com.smartlms.service;

import com.smartlms.model.*;
import com.smartlms.storage.DataStore;
import java.util.*;
import java.util.stream.Collectors;

public class SmartRecommendationEngine {
    private final DataStore store;

    public static class CourseRecommendation {
        private final Course course;
        private final double matchScore;
        private final String reason;

        public CourseRecommendation(Course course, double matchScore, String reason) {
            this.course = course;
            this.matchScore = matchScore;
            this.reason = reason;
        }

        public Course getCourse() { return course; }
        public double getMatchScore() { return matchScore; }
        public String getReason() { return reason; }
    }

    public static class StudyPlanItem {
        private final int day;
        private final String courseTitle;
        private final Lesson lesson;

        public StudyPlanItem(int day, String courseTitle, Lesson lesson) {
            this.day = day;
            this.courseTitle = courseTitle;
            this.lesson = lesson;
        }

        public int getDay() { return day; }
        public String getCourseTitle() { return courseTitle; }
        public Lesson getLesson() { return lesson; }
    }

    public SmartRecommendationEngine(DataStore store) {
        this.store = store;
    }

    public List<CourseRecommendation> recommendCoursesForStudent(String studentId, int limit) {
        List<Enrollment> enrollments = store.getEnrollments().stream()
                .filter(e -> e.getStudentId().equals(studentId))
                .collect(Collectors.toList());

        Set<String> enrolledCourseIds = enrollments.stream()
                .map(Enrollment::getCourseId)
                .collect(Collectors.toSet());

        Set<String> preferredTags = new HashSet<>();
        Set<String> preferredCategories = new HashSet<>();
        double totalQuizAvg = 0.0;
        int quizCount = 0;

        for (Enrollment e : enrollments) {
            Course c = store.getCourses().get(e.getCourseId());
            if (c != null) {
                preferredTags.addAll(c.getTags());
                preferredCategories.add(c.getCategory().toLowerCase());
            }
            if (!e.getQuizScores().isEmpty()) {
                totalQuizAvg += e.getAverageQuizScore();
                quizCount++;
            }
        }
        double overallAvg = quizCount == 0 ? 70.0 : totalQuizAvg / quizCount;

        List<CourseRecommendation> recommendations = new ArrayList<>();
        for (Course candidate : store.getCourses().values()) {
            if (enrolledCourseIds.contains(candidate.getId())) {
                continue;
            }
            double score = 10.0;
            List<String> reasons = new ArrayList<>();

            long matchingTags = candidate.getTags().stream()
                    .filter(preferredTags::contains)
                    .count();
            if (matchingTags > 0) {
                score += matchingTags * 20.0;
                reasons.add(matchingTags + " matching topic tag(s)");
            }

            if (preferredCategories.contains(candidate.getCategory().toLowerCase())) {
                score += 25.0;
                reasons.add("matches your category interest");
            }

            if (overallAvg >= 75.0 && candidate.getDifficulty() != Course.Difficulty.BEGINNER) {
                score += 30.0;
                reasons.add("adaptive next-level difficulty (" + candidate.getDifficulty() + ")");
            } else if (overallAvg < 60.0 && candidate.getDifficulty() == Course.Difficulty.BEGINNER) {
                score += 25.0;
                reasons.add("solid foundation match");
            }

            if (reasons.isEmpty()) {
                reasons.add("popular course in catalog");
            }
            recommendations.add(new CourseRecommendation(candidate, score, String.join(", ", reasons)));
        }

        return recommendations.stream()
                .sorted(Comparator.comparingDouble(CourseRecommendation::getMatchScore).reversed())
                .limit(limit)
                .collect(Collectors.toList());
    }

    public List<StudyPlanItem> generateStudyPlan(String studentId, int dailyMinutes) {
        int budget = Math.max(15, dailyMinutes);
        List<Enrollment> enrollments = store.getEnrollments().stream()
                .filter(e -> e.getStudentId().equals(studentId))
                .collect(Collectors.toList());

        List<StudyPlanItem> plan = new ArrayList<>();
        int currentDay = 1;
        int remainingToday = budget;

        for (Enrollment e : enrollments) {
            Course course = store.getCourses().get(e.getCourseId());
            if (course == null) continue;
            for (Lesson lesson : course.getLessons()) {
                if (e.getCompletedLessonIds().contains(lesson.getId())) {
                    continue;
                }
                if (lesson.getDurationMinutes() > remainingToday && remainingToday < budget) {
                    currentDay++;
                    remainingToday = budget;
                }
                plan.add(new StudyPlanItem(currentDay, course.getTitle(), lesson));
                remainingToday -= lesson.getDurationMinutes();
                if (remainingToday <= 0) {
                    currentDay++;
                    remainingToday = budget;
                }
            }
        }
        return plan;
    }

    public List<String> detectAtRiskStudents(String courseId) {
        Course course = store.getCourses().get(courseId.toUpperCase());
        if (course == null) return Collections.emptyList();

        List<String> alerts = new ArrayList<>();
        for (Enrollment e : store.getEnrollments()) {
            if (!e.getCourseId().equalsIgnoreCase(courseId)) continue;
            double progress = e.getProgressPercentage(course.getLessons().size());
            double quizAvg = e.getQuizScores().isEmpty() ? 100.0 : e.getAverageQuizScore();

            if (progress < 30.0 || quizAvg < 50.0) {
                User student = store.getUsers().get(e.getStudentId());
                String name = student != null ? student.getName() : e.getStudentId();
                alerts.add(String.format("%s (%s) -> Progress: %.1f%%, Avg Quiz: %.1f%%",
                        name, e.getStudentId(), progress, quizAvg));
            }
        }
        return alerts;
    }
}
