package com.smartlms.service;

import com.smartlms.model.Course;
import com.smartlms.model.Lesson;
import com.smartlms.model.Quiz;
import com.smartlms.storage.DataStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class CourseService {
    private final DataStore store;

    public CourseService(DataStore store) {
        this.store = store;
    }

    public Course createCourse(String title, String category, Course.Difficulty difficulty,
                               String instructorId, int maxStudents, List<String> tags) {
        String id = "C" + (100 + store.getCourses().size() + 1);
        Course course = new Course(id, title.trim(), category.trim(), difficulty, instructorId, maxStudents);
        if (tags != null) {
            for (String tag : tags) {
                course.addTag(tag);
            }
        }
        store.getCourses().put(id, course);
        store.save();
        return course;
    }

    public List<Course> getAllCourses() {
        return new ArrayList<>(store.getCourses().values());
    }

    public Optional<Course> getCourseById(String courseId) {
        return Optional.ofNullable(store.getCourses().get(courseId.trim().toUpperCase()));
    }

    public List<Course> getCoursesByInstructor(String instructorId) {
        return store.getCourses().values().stream()
                .filter(c -> c.getInstructorId().equals(instructorId))
                .collect(Collectors.toList());
    }

    public List<Course> searchCourses(String keyword) {
        String q = keyword.toLowerCase().trim();
        return store.getCourses().values().stream()
                .filter(c -> c.getTitle().toLowerCase().contains(q)
                        || c.getCategory().toLowerCase().contains(q)
                        || c.getTags().stream().anyMatch(t -> t.contains(q)))
                .collect(Collectors.toList());
    }

    public Lesson addLessonToCourse(String courseId, String title, int durationMinutes, String summary) {
        Course course = getCourseById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Course not found: " + courseId));
        String lessonId = "L" + courseId.replaceAll("\\D+", "") + "-" + (course.getLessons().size() + 1);
        Lesson lesson = new Lesson(lessonId, title.trim(), durationMinutes, summary.trim());
        course.addLesson(lesson);
        store.save();
        return lesson;
    }

    public void addQuizToCourse(String courseId, Quiz quiz) {
        Course course = getCourseById(courseId)
                .orElseThrow(() -> new IllegalArgumentException("Course not found: " + courseId));
        course.addQuiz(quiz);
        store.save();
    }
}
