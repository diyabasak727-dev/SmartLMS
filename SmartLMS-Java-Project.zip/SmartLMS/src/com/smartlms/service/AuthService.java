package com.smartlms.service;

import com.smartlms.model.Role;
import com.smartlms.model.User;
import com.smartlms.storage.DataStore;
import java.util.Collection;
import java.util.Optional;

public class AuthService {
    private final DataStore store;

    public AuthService(DataStore store) {
        this.store = store;
    }

    public User register(String name, String email, String password, Role role) {
        String normalizedEmail = email.toLowerCase().trim();
        boolean exists = store.getUsers().values().stream()
                .anyMatch(u -> u.getEmail().equals(normalizedEmail));
        if (exists) {
            throw new IllegalArgumentException("An account with this email already exists.");
        }
        String id = "U" + (100 + store.getUsers().size() + 1);
        User user = new User(id, name.trim(), normalizedEmail, DataStore.sha256(password), role);
        store.getUsers().put(id, user);
        store.save();
        return user;
    }

    public Optional<User> login(String email, String password) {
        String normalizedEmail = email.toLowerCase().trim();
        String hash = DataStore.sha256(password);
        return store.getUsers().values().stream()
                .filter(u -> u.getEmail().equals(normalizedEmail) && u.getPasswordHash().equals(hash))
                .findFirst();
    }

    public Optional<User> getUserById(String id) {
        return Optional.ofNullable(store.getUsers().get(id));
    }

    public Collection<User> getAllUsers() {
        return store.getUsers().values();
    }
}
