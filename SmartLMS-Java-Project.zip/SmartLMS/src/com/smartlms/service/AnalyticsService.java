package com.smartlms.service;

import com.smartlms.model.Course;
import com.smartlms.model.Enrollment;
import com.smartlms.model.Role;
import com.smartlms.model.User;
import com.smartlms.storage.DataStore;
import java.util.*;
import java.util.stream.Collectors;

public class AnalyticsService {
    private final DataStore store;

    public AnalyticsService(DataStore store) {
        this.store = store;
    }

    public String getStudentSummary(String studentId) {
        List<Enrollment> enrollments = store.getEnrollments().stream()
                .filter(e -> e.getStudentId().equals(studentId))
                .collect(Collectors.toList());
        if (enrollments.isEmpty()) {
            return "No active enrollments yet.";
        }
        double totalProgress = 0.0;
        double totalQuiz = 0.0;
        int quizEnrollments = 0;

        for (Enrollment e : enrollments) {
            Course c = store.getCourses().get(e.getCourseId());
            int totalLessons = c != null ? c.getLessons().size() : 0;
            totalProgress += e.getProgressPercentage(totalLessons);
            if (!e.getQuizScores().isEmpty()) {
                totalQuiz += e.getAverageQuizScore();
                quizEnrollments++;
            }
        }
        double avgProgress = totalProgress / enrollments.size();
        double avgQuiz = quizEnrollments == 0 ? 0.0 : totalQuiz / quizEnrollments;

        return String.format("Enrolled Courses: %d | Avg Completion: %.1f%% | Avg Quiz Score: %.1f%%",
                enrollments.size(), avgProgress, avgQuiz);
    }

    public String getCourseAnalytics(String courseId) {
        Course c = store.getCourses().get(courseId.toUpperCase());
        if (c == null) return "Course not found.";
        List<Enrollment> list = store.getEnrollments().stream()
                .filter(e -> e.getCourseId().equalsIgnoreCase(courseId))
                .collect(Collectors.toList());
        if (list.isEmpty()) {
            return String.format("%s: 0 students enrolled.", c.getTitle());
        }
        double avgProg = list.stream()
                .mapToDouble(e -> e.getProgressPercentage(c.getLessons().size()))
                .average().orElse(0.0);
        double avgQuiz = list.stream()
                .filter(e -> !e.getQuizScores().isEmpty())
                .mapToDouble(Enrollment::getAverageQuizScore)
                .average().orElse(0.0);
        return String.format("%s (%s) | Enrolled: %d/%d | Avg Progress: %.1f%% | Avg Quiz: %.1f%%",
                c.getTitle(), c.getId(), list.size(), c.getMaxStudents(), avgProg, avgQuiz);
    }

    public List<String> getTopStudentsLeaderboard(int limit) {
        Map<String, Double> studentScores = new HashMap<>();
        for (User u : store.getUsers().values()) {
            if (u.getRole() != Role.STUDENT) continue;
            List<Enrollment> list = store.getEnrollments().stream()
                    .filter(e -> e.getStudentId().equals(u.getId()))
                    .collect(Collectors.toList());
            if (list.isEmpty()) continue;
            double avgQuiz = list.stream()
                    .filter(e -> !e.getQuizScores().isEmpty())
                    .mapToDouble(Enrollment::getAverageQuizScore)
                    .average().orElse(0.0);
            studentScores.put(u.getName() + " (" + u.getId() + ")", avgQuiz);
        }
        return studentScores.entrySet().stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(limit)
                .map(e -> String.format("%s - Avg Quiz: %.1f%%", e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }
}
