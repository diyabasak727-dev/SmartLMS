package com.smartlms.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Enrollment implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String studentId;
    private final String courseId;
    private final LocalDateTime enrolledAt;
    private final Set<String> completedLessonIds = new HashSet<>();
    private final Map<String, Double> quizScores = new HashMap<>();

    public Enrollment(String studentId, String courseId) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.enrolledAt = LocalDateTime.now();
    }

    public String getStudentId() { return studentId; }
    public String getCourseId() { return courseId; }
    public LocalDateTime getEnrolledAt() { return enrolledAt; }

    public void markLessonCompleted(String lessonId) {
        completedLessonIds.add(lessonId);
    }

    public Set<String> getCompletedLessonIds() {
        return Collections.unmodifiableSet(completedLessonIds);
    }

    public void recordQuizScore(String quizId, double percentage) {
        quizScores.put(quizId, percentage);
    }

    public Map<String, Double> getQuizScores() {
        return Collections.unmodifiableMap(quizScores);
    }

    public double getAverageQuizScore() {
        if (quizScores.isEmpty()) return 0.0;
        return quizScores.values().stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
    }

    public double getProgressPercentage(int totalLessons) {
        if (totalLessons <= 0) return 100.0;
        return Math.min(100.0, (completedLessonIds.size() * 100.0) / totalLessons);
    }
}
