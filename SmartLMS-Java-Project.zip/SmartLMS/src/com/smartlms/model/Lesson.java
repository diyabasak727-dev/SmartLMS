package com.smartlms.model;

import java.io.Serializable;

public class Lesson implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String id;
    private String title;
    private int durationMinutes;
    private String contentSummary;

    public Lesson(String id, String title, int durationMinutes, String contentSummary) {
        this.id = id;
        this.title = title;
        this.durationMinutes = durationMinutes;
        this.contentSummary = contentSummary;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int durationMinutes) { this.durationMinutes = durationMinutes; }
    public String getContentSummary() { return contentSummary; }
    public void setContentSummary(String contentSummary) { this.contentSummary = contentSummary; }

    @Override
    public String toString() {
        return String.format("[%s] %s (%d min) - %s", id, title, durationMinutes, contentSummary);
    }
}
