package com.smartlms.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Question implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String prompt;
    private final List<String> options;
    private final int correctOptionIndex;

    public Question(String prompt, List<String> options, int correctOptionIndex) {
        this.prompt = prompt;
        this.options = new ArrayList<>(options);
        this.correctOptionIndex = correctOptionIndex;
    }

    public String getPrompt() { return prompt; }
    public List<String> getOptions() { return Collections.unmodifiableList(options); }
    public int getCorrectOptionIndex() { return correctOptionIndex; }

    public boolean isCorrect(int selectedIndex) {
        return selectedIndex == correctOptionIndex;
    }
}
