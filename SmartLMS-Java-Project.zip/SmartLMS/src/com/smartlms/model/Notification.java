package com.smartlms.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Notification implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String id;
    private final String userId;
    private final String message;
    private final LocalDateTime createdAt;
    private boolean read;

    public Notification(String id, String userId, String message) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.createdAt = LocalDateTime.now();
        this.read = false;
    }

    public String getId() { return id; }
    public String getUserId() { return userId; }
    public String getMessage() { return message; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public boolean isRead() { return read; }
    public void markAsRead() { this.read = true; }

    @Override
    public String toString() {
        String status = read ? "READ" : "NEW";
        String time = createdAt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        return String.format("[%s] (%s) %s", status, time, message);
    }
}
