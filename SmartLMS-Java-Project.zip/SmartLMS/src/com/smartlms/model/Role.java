package com.smartlms.model;

public enum Role {
    ADMIN,
    INSTRUCTOR,
    STUDENT
}
