package com.smartlms.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Course implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum Difficulty {
        BEGINNER, INTERMEDIATE, ADVANCED
    }

    private final String id;
    private String title;
    private String category;
    private Difficulty difficulty;
    private String instructorId;
    private int maxStudents;
    private final Set<String> tags = new HashSet<>();
    private final List<Lesson> lessons = new ArrayList<>();
    private final List<Quiz> quizzes = new ArrayList<>();

    public Course(String id, String title, String category, Difficulty difficulty, String instructorId, int maxStudents) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.difficulty = difficulty;
        this.instructorId = instructorId;
        this.maxStudents = maxStudents;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }
    public String getInstructorId() { return instructorId; }
    public void setInstructorId(String instructorId) { this.instructorId = instructorId; }
    public int getMaxStudents() { return maxStudents; }
    public void setMaxStudents(int maxStudents) { this.maxStudents = maxStudents; }

    public void addTag(String tag) {
        if (tag != null && !tag.isBlank()) {
            tags.add(tag.toLowerCase().trim());
        }
    }

    public Set<String> getTags() { return Collections.unmodifiableSet(tags); }

    public void addLesson(Lesson lesson) { lessons.add(lesson); }
    public List<Lesson> getLessons() { return Collections.unmodifiableList(lessons); }

    public void addQuiz(Quiz quiz) { quizzes.add(quiz); }
    public List<Quiz> getQuizzes() { return Collections.unmodifiableList(quizzes); }

    public int getTotalDurationMinutes() {
        return lessons.stream().mapToInt(Lesson::getDurationMinutes).sum();
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | %s | %s | Lessons: %d | Quizzes: %d",
                id, title, category, difficulty, lessons.size(), quizzes.size());
    }
}
