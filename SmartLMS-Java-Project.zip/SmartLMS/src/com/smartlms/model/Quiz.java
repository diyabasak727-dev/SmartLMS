package com.smartlms.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Quiz implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String id;
    private String title;
    private final List<Question> questions = new ArrayList<>();

    public Quiz(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public void addQuestion(Question q) {
        questions.add(q);
    }

    public List<Question> getQuestions() {
        return Collections.unmodifiableList(questions);
    }
}
